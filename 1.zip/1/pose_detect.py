import cv2
import argparse
from openpose import Openpose, draw_person_pose

# load model
openpose = Openpose(weights_file = "C:\\Users\\root\\Desktop\\1\\models\\posenet.pth", training = False)

# read image
img = cv2.imread("C:\\Users\\root\\Desktop\\1\\raw\\Fh1.jpg")

# inference
poses, _ = openpose.detect(img,)

# draw and save image
img1 = draw_person_pose(cv2.cvtColor(img, cv2.COLOR_BGR2RGB), poses)
img2=img1-img
print('Saving result into result.png...')
cv2.imwrite('C:/Users/root/Desktop/1/data/result.png', img2)
print('done')
